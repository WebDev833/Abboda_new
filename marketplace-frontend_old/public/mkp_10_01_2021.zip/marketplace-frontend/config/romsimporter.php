<?php

return [
  'defaultemail' =>  'support@abboda.com',
  'defaultphone' =>  '+1 9876543210',
  'defaultrating' =>  4,
  'defaultcairolat' =>  '30.0594838',
  'defaultcairolon' =>  '31.2234448',
  'defaultaddress' =>  'Cairo',
  'defaultproductprice' =>  '15:00',
];