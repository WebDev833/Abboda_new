$(function() {
	'use strict'
	
	// Peity-donut
	$('.peity-donut').peity('donut');

});