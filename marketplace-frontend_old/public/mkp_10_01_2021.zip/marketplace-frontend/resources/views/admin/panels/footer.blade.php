<!-- Main Footer-->
<div class="main-footer text-center">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <span>Copyright © {{ date('Y') }} <a href="{{ route('home') }}">Abboda</a>. Managed by <a href="https://www.websoftgeeks.com/">Web Soft Geeks</a> All rights reserved.</span>
      </div>
    </div>
  </div>
</div>
<!--End Footer-->