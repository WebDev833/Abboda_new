<!-- Loader -->
<div id="global-loader">
  <img src="{{ asset('admin-assets/img/loader.svg') }}" class="loader-img" alt="Loader">
</div>
<!-- End Loader -->