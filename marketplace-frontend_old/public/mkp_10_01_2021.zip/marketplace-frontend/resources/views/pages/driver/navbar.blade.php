<nav class="ps-store-link mb-30">
    <ul>
        <li><a href="{{route('driver.neworders')}}">New Orders</a></li>
        <li><a href="{{route('driver.myorders')}}">My Orders</a></li>
        {{-- <li><a href="{{route('driver.myratings')}}">My Ratings</a></li> --}}
        <li><a href="{{route('driver.myearnings')}}">My Earnings</a></li>
        <li><a href="{{route('driver.editProfilepage')}}">Edit Profile</a></li>
    </ul>
</nav>