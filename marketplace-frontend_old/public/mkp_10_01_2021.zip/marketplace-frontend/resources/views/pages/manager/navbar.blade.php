<nav class="ps-store-link mb-30">
    <ul>
        <li><a href="{{route('manager.neworders')}}">New Orders</a></li>
        <li><a href="{{route('manager.myorders')}}">My Orders</a></li>
        <li><a href="{{route('manager.transactions')}}">My Transactions</a></li>
        <li><a href="{{route('manager.ordersettlements')}}">Order Settlements</a></li>
    </ul>
</nav>