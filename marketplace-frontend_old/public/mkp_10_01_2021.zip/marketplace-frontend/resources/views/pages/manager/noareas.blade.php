@extends('pages.manager.managerlayout')
@section('managerpage')
    <div class="roms--orders">
        @include('panels.success')
        @include('panels.errors')
        <h5 class="mb-5">Nothing to manage yet.</h5>
</div>
@endsection
