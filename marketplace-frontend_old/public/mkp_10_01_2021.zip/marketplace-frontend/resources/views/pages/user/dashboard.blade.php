@extends('pages.user.userlayout')
@section('userpage')
<nav class="ps-store-link">
    <ul>
        <li><a href="">My Orders</a></li>
        <li><a href="">Edit Profile</a></li>
    </ul>
</nav>
<div class="ps-shopping ps-tab-root">
  dashboard
</div>
@endsection
