<nav class="ps-store-link mb-30">
    <ul>
        <li><a href="{{route('user.myorders')}}">My Orders</a></li>
        <li><a href="{{route('user.editProfilepage')}}">Edit Profile</a></li>
    </ul>
</nav>