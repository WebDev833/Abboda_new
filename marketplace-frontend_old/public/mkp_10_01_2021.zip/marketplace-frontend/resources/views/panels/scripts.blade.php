    <script src="{{ asset('plugins/jquery-1.12.4.min.js')}}"></script>
    <script src="{{ asset('plugins/popper.min.js')}}"></script>
    <script src="{{ asset('plugins/owl-carousel/owl.carousel.min.js')}}"></script>
    <script src="{{ asset('plugins/bootstrap4/js/bootstrap.min.js')}}"></script>
    <script src="{{ asset('plugins/imagesloaded.pkgd.min.js')}}"></script>
    <script src="{{ asset('plugins/masonry.pkgd.min.js')}}"></script>
    <script src="{{ asset('plugins/isotope.pkgd.min.js')}}"></script>
    <script src="{{ asset('plugins/jquery.matchHeight-min.js')}}"></script>
    <script src="{{ asset('plugins/slick/slick/slick.min.js')}}"></script>
    <script src="{{ asset('plugins/jquery-bar-rating/dist/jquery.barrating.min.js')}}"></script>
    <script src="{{ asset('plugins/slick-animation.min.js')}}"></script>
    <script src="{{ asset('plugins/lightGallery-master/dist/js/lightgallery-all.min.js')}}"></script>
    <script src="{{ asset('plugins/jquery-ui/jquery-ui.min.js')}}"></script>
    <script src="{{ asset('plugins/sticky-sidebar/dist/sticky-sidebar.min.js')}}"></script>
    <script src="{{ asset('plugins/jquery.slimscroll.min.js')}}"></script>
    <script src="{{ asset('plugins/select2/dist/js/select2.full.min.js')}}"></script>
    @yield('vendor-scripts')
    <!-- custom scripts-->
    <script src="{{ asset('js/main.js')}}"></script>
    <script src="{{ asset('js/custom.js')}}"></script>

    @yield('page-scripts')
