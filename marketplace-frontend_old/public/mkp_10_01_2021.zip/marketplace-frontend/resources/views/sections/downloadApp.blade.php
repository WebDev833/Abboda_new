<div class="roms--home-section-download-app">
    <div class="ps-container">
        <h2>Apps Have Launched</h2>
        <p>Click the buttons below to download the app now.</p>
        <p class="download-link">
            <a href="#">
                <img src="{{asset('img/google-play.png')}}"  alt="">
            </a>
            <a href="#">
                <img src="{{asset('img/app-store.png')}}" alt="">
            </a>
        </p>
    </div>
</div>