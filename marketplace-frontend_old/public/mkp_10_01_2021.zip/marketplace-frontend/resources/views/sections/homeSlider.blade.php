<div id="homepage-photo">
    <div class="ps-home-search bg--cover" data-background="img/home/home-photo/banner.jpg">
        <div class="ps-section__wrapper">
            <div class="ps-section__header">
                {{-- <p><strong>171,484,880</strong> stock photos, vectors and videos</p> --}}
                <h3>The all-in-one platform for your basic needs.</h3>
            </div>
              @include('panels.search')
          </div>
    </div>
</div>

{{-- Slider Bottom Note Bar --}}
<div class="roms--home-call mb-5">
    <div class="ps-container">
      <div class="roms--home-call">
        <div class="roms--home-call-left">
          <h4>
            <span>Lorem Ipsum is simply dummy text of the printing and typesetting industry!</span>
          </h4>
        </div>
        <div class="roms--home-call-right">
          <a href="javascript:void(0);">Contact Us</a>
        </div>
      </div>
    </div>
</div>