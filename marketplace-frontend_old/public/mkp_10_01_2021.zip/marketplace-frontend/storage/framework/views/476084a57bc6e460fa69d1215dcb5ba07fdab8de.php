<?php if(isset($frontSettings) && $frontSettings['breadcrumb'] === TRUE): ?>
<div class="ps-breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="<?php echo e(url('')); ?>">Home</a></li>
            <li><?php echo e($frontSettings['title']); ?></li>
        </ul>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/abboda/public_html/marketplace-frontend/resources/views/panels/breadcrumb.blade.php ENDPATH**/ ?>