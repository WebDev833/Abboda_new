    <script src="<?php echo e(asset('plugins/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/owl-carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap4/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/masonry.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery.matchHeight-min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/slick/slick/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery-bar-rating/dist/jquery.barrating.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/slick-animation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/lightGallery-master/dist/js/lightgallery-all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sticky-sidebar/dist/sticky-sidebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/select2/dist/js/select2.full.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('vendor-scripts'); ?>
    <!-- custom scripts-->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

    <?php echo $__env->yieldContent('page-scripts'); ?>
<?php /**PATH /home/abboda/public_html/marketplace-frontend/resources/views/panels/scripts.blade.php ENDPATH**/ ?>