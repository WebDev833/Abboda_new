    <footer class="ps-footer">
        <div class="ps-container">
            <div class="ps-footer__widgets">
                <aside class="widget widget_footer">
                    <h4 class="widget-title">Quick links 2 </h4>
                    <ul class="ps-list--link">
                        <li><a href="#">Policy 2 </a></li>
                        <li><a href="#">Term & Condition 2 </a></li>
                        <li><a href="#">Shipping 2 </a></li>
                        <li><a href="#">Return 2 </a></li>
                        <li><a href="faqs.html">FAQs 2 </a></li>
                    </ul>
                </aside>
                <aside class="widget widget_footer">
                    <h4 class="widget-title">Quick links 2 </h4>
                    <ul class="ps-list--link">
                        <li><a href="#">Policy 2 </a></li>
                        <li><a href="#">Term & Condition 2 </a></li>
                        <li><a href="#">Shipping 2 </a></li>
                        <li><a href="#">Return 2 </a></li>
                        <li><a href="faqs.html">FAQs 2 </a></li>
                    </ul>
                </aside>
                <aside class="widget widget_footer">
                    <h4 class="widget-title">Quick links</h4>
                    <ul class="ps-list--link">
                        <li><a href="#">Policy</a></li>
                        <li><a href="#">Term & Condition</a></li>
                        <li><a href="#">Shipping</a></li>
                        <li><a href="#">Return</a></li>
                        <li><a href="faqs.html">FAQs</a></li>
                    </ul>
                </aside>
                <aside class="widget widget_footer">
                    <h4 class="widget-title">Company</h4>
                    <ul class="ps-list--link">
                        <li><a href="about-us.html">About Us</a></li>
                        <li><a href="#">Affilate</a></li>
                        <li><a href="#">Career</a></li>
                        <li><a href="contact-us.html">Contact</a></li>
                    </ul>
                </aside>
                <aside class="widget widget_footer">
                    <h4 class="widget-title">Bussiness</h4>
                    <ul class="ps-list--link">
                        <li><a href="#">Our Press</a></li>
                        <li><a href="checkout.html">Checkout</a></li>
                        <li><a href="my-account.html">My account</a></li>
                        <li><a href="shop-default.html">Shop</a></li>
                    </ul>
                </aside>
                                <aside class="widget widget_footer widget_contact-us">
                    <h4 class="widget-title">Contact Us</h4>
                    <div class="widget_content">
                        <p>Call us 24/7</p>
                        <h3>9876 543 210</h3>
                        <p>#123 ABC city state country 101010 <br><a
                                href="https://www.websoftgeeks.com/">support@abboda.com</a>
                        </p>
                        <ul class="ps-list--social">
                            <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
                            <li><a class="instagram" href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </aside>
            </div>
            
            <div class="ps-footer__copyright">
                <p>© <?php echo e(date('Y')); ?> ABBODA. All Rights Reserved</p>

                
            </div>
        </div>
    </footer>
<?php /**PATH /home/abboda/public_html/marketplace-frontend/resources/views/panels/footer.blade.php ENDPATH**/ ?>