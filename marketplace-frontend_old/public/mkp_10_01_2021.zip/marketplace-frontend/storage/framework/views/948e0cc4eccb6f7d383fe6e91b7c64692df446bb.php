<?php if(isset($pageConfigs)): ?>
<?php echo Front::updatePageConfig($pageConfigs); ?>

<?php endif; ?>
<?php
$frontSettings = Front::frontSettings();
?>

<?php $__env->startSection('content'); ?>
<div class="ps-my-account">
    <div class="container">
        <?php echo Form::open(['route'=>'login', 'method'=>'POST','class'=>'ps-form--account ps-tab-root']); ?>

        <ul class="ps-tab-list d-none">
            <li class="active"><a href="#sign-in">Login</a></li>
            <li><a href="#register">Register</a></li>
        </ul>
        <div class="ps-tabs" id="roms--login">
            <div class="ps-tab active" id="sign-in">
                <div class="ps-form__content">
                    <h5><?php echo e(trans('front.log_in_to_your_account')); ?></h5>
                    <?php echo $__env->make('panels.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form-group">
                        <?php echo Form::email('email', old('email'),
                        ["class"=>"form-control","placeholder"=>trans('front.enter_your_email')]); ?>

                    </div>
                    <div class="form-group form-forgot">
                        <?php echo Form::password('password', ['class'=>'form-control','placeholder'=>
                        trans('front.enter_your_password')]); ?>

                        <a href="<?php echo e(route('forgotpasswordpage')); ?>"><?php echo e(trans('front.login_forgot_text')); ?></a>
                    </div>
                    <div class="form-group">
                        <div class="ps-checkbox">
                            <?php echo Form::checkbox('remember',old('remember') ? 'checked' : '',old('remember') ? 'checked' :
                            '', ["id"=>"remember-me","class"=>"form-control"]); ?>

                            <label for="remember-me"><?php echo e(trans('front.login_remember_me_text')); ?></label>
                        </div>
                    </div>
                    <div class="form-group submtit">
                        <button type="submit"
                            class="ps-btn ps-btn--fullwidth"><?php echo e(trans('front.login_button_text')); ?></button>
                      
                    </div>
                    <a href="<?php echo e(route('register')); ?>" ><?php echo e(trans('front.donot_have_an_account_text')); ?></a>
                </div>
                <div class="ps-form__footer">
                    <p><?php echo e(trans('front.connect_with_text')); ?> :</p>
                    <ul class="ps-list--social">
                        <li><a class="facebook" href="<?php echo e(route('socialLogin',['provider'=>'facebook'])); ?>"><i class="fa fa-facebook"></i> <?php echo e(trans('front.facebook_text')); ?></a></li>
                        <li><a class="google" href="<?php echo e(route('socialLogin',['provider'=>'google'])); ?>"><i class="fa fa-google-plus"></i> <?php echo e(trans('front.google_text')); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.static', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abboda/public_html/marketplace-frontend/resources/views/pages/user/auth/login.blade.php ENDPATH**/ ?>